Given /^the following movies exist:$/ do |movie_table|
	movie_table.hashes.each do |movie|
		Movie.create!(movie)
	end
end

Then /^the director of "(.*?)" should be "(.*?)"$/ do |arg1, arg2|
  Movie.where(title: arg1, director: arg2)
end
